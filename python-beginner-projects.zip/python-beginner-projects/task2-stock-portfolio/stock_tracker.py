from pathlib import Path
import csv

# Example prices only; these are manually defined and are not live market prices.
STOCK_PRICES = {
    "AAPL": 180.00,
    "TSLA": 250.00,
    "GOOGL": 140.00,
    "MSFT": 420.00,
    "AMZN": 185.00,
}


def get_positive_quantity(prompt):
    while True:
        raw_value = input(prompt).strip()
        try:
            quantity = int(raw_value)
            if quantity <= 0:
                print("Quantity must be a positive whole number.")
                continue
            return quantity
        except ValueError:
            print("Please enter a valid whole number.")


def track_portfolio():
    print("\n=== Stock Portfolio Tracker ===")
    print("Available stocks and example prices:")
    for symbol, price in STOCK_PRICES.items():
        print(f"  {symbol}: ${price:,.2f} per share")

    holdings = {}
    while True:
        symbol = input("\nEnter a stock symbol (or 'done' to finish): ").strip().upper()
        if symbol == "DONE":
            break
        if symbol not in STOCK_PRICES:
            print("Unknown symbol. Choose one from the list above.")
            continue

        quantity = get_positive_quantity(f"How many shares of {symbol}? ")
        holdings[symbol] = holdings.get(symbol, 0) + quantity

    if not holdings:
        print("No holdings entered. Nothing to calculate.")
        return

    print("\n=== Portfolio Summary ===")
    total_value = 0.0
    rows = []
    for symbol, quantity in holdings.items():
        price = STOCK_PRICES[symbol]
        value = price * quantity
        total_value += value
        rows.append((symbol, quantity, price, value))
        print(f"{symbol}: {quantity} shares x ${price:,.2f} = ${value:,.2f}")

    print(f"Total investment value: ${total_value:,.2f}")

    save = input("Save the summary to portfolio.csv? (y/n): ").strip().lower()
    if save == "y":
        output_path = Path(__file__).with_name("portfolio.csv")
        with output_path.open("w", newline="", encoding="utf-8") as csv_file:
            writer = csv.writer(csv_file)
            writer.writerow(["Symbol", "Quantity", "Price per Share", "Total Value"])
            for row in rows:
                writer.writerow([row[0], row[1], f"{row[2]:.2f}", f"{row[3]:.2f}"])
            writer.writerow([])
            writer.writerow(["", "", "Portfolio Total", f"{total_value:.2f}"])
        print(f"Summary saved to: {output_path}")


if __name__ == "__main__":
    track_portfolio()
