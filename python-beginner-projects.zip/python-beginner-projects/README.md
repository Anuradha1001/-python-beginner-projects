# Python Beginner Projects

Two beginner-friendly Python console applications built using core Python concepts.

## Projects

### 1. Hangman Game
A text-based word-guessing game. The program randomly selects one of five predefined words. Guess one letter at a time; the game ends when you guess the word or make six incorrect guesses.

**Concepts:** `random`, `while` loops, `if/else`, strings, lists, sets, user input.

### 2. Stock Portfolio Tracker
A console application that accepts stock symbols and share quantities, calculates each holding's value, and displays the total portfolio value. You can optionally save the result to a CSV file.

**Concepts:** dictionaries, input/output, loops, validation, arithmetic, CSV file handling.

> **Important:** Stock prices in this project are hardcoded examples for programming practice. They are not live market prices and should not be used for investment decisions.

## Requirements
- Python 3.8 or newer
- No external packages required

## How to run

Open a terminal in the repository folder.

### Run Hangman
```bash
python task1-hangman/hangman.py
```

### Run Stock Portfolio Tracker
```bash
python task2-stock-portfolio/stock_tracker.py
```

On some systems, use `python3` instead of `python`.

## Example stock calculation
If you enter 2 shares of AAPL at the example price of $180 and 3 shares of TSLA at $250:
- AAPL: 2 × $180 = $360
- TSLA: 3 × $250 = $750
- Total portfolio value: $1,110

## Repository structure
```text
python-beginner-projects/
├── README.md
├── .gitignore
├── task1-hangman/
│   └── hangman.py
└── task2-stock-portfolio/
    └── stock_tracker.py
```

## Author
Add your name here.
