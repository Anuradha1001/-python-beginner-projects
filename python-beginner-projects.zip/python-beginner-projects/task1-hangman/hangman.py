import random

WORDS = ["python", "hangman", "computer", "program", "developer"]
MAX_INCORRECT_GUESSES = 6


def play_hangman():
    secret_word = random.choice(WORDS)
    guessed_letters = set()
    incorrect_guesses = 0

    print("\n=== Hangman Game ===")
    print(f"Guess the word one letter at a time. You have {MAX_INCORRECT_GUESSES} incorrect guesses.")

    while incorrect_guesses < MAX_INCORRECT_GUESSES:
        display_word = " ".join(
            letter if letter in guessed_letters else "_" for letter in secret_word
        )
        print(f"\nWord: {display_word}")
        print(f"Incorrect guesses remaining: {MAX_INCORRECT_GUESSES - incorrect_guesses}")
        print("Guessed letters:", ", ".join(sorted(guessed_letters)) if guessed_letters else "None")

        guess = input("Enter one letter: ").strip().lower()

        if len(guess) != 1 or not guess.isalpha():
            print("Please enter exactly one letter (A-Z).")
            continue

        if guess in guessed_letters:
            print("You already guessed that letter. Try another.")
            continue

        guessed_letters.add(guess)

        if guess in secret_word:
            print("Correct!")
            if all(letter in guessed_letters for letter in secret_word):
                print(f"Congratulations! You guessed the word: {secret_word}")
                return
        else:
            incorrect_guesses += 1
            print("Sorry, that letter is not in the word.")

    print(f"Game over! The word was: {secret_word}")


if __name__ == "__main__":
    play_hangman()
